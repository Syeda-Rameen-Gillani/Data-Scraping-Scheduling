import json

with open("your_file.json", "r", encoding="utf-8") as f:
    data = json.load(f)

print(len(data))
print(data[0])
